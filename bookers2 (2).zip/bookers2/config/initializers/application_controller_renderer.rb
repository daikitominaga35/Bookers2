# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '6f41908fc675c32ee6864bf70884178a5c3db83a6fca28edd1aefc30cf12e2f46c33807e3f5e0778dd9feb10e305e68f488b32d3a02a113fff0883d5b0e1d688'
